class QCUser {
  final String userId;
  final String firstName;
  final String lastName;

  QCUser({
    required this.userId,
    required this.firstName,
    required this.lastName,
  });

  //TODO: Create map to store or retrieve data from db
}
